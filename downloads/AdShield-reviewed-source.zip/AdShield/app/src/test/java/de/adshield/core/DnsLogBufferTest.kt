package de.adshield.core
import org.junit.Assert.*
import org.junit.Test
import org.xbill.DNS.Type
class DnsLogBufferTest {
 @Test fun boundedNewestFirst(){val b=DnsLogBuffer();repeat(200){b.record("d$it.example",Type.A,Outcome.ALLOWED)};assertEquals(150,b.snapshot.value.size);assertEquals("d199.example",b.snapshot.value.first().domain);assertEquals("d50.example",b.snapshot.value.last().domain)}
 @Test fun normalizesAndClears(){val b=DnsLogBuffer();b.record(" EXAMPLE.COM. ",Type.A,Outcome.BLOCKED);assertEquals("example.com",b.snapshot.value.single().domain);b.clear();assertTrue(b.snapshot.value.isEmpty());b.record("next.example",Type.A,Outcome.ALLOWED);assertEquals(1,b.snapshot.value.size)}
}
