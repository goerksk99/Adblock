package de.adshield.core
import org.junit.Assert.*
import org.junit.Test
class PackedDomainSetTest {
 @Test fun matchesSetIncludingBoundaries(){val names=(0..10000).map{"host-$it.example"}.toSet();val packed=PackedDomainSet.of(names);assertEquals(names,packed);assertEquals(names.toList().sorted(),packed.toList());for(n in names)assertTrue(n in packed);for(n in listOf("","host-10001.example","host-0.exampl","host-0.examplex"))assertFalse(n in packed);assertFalse("a.example" in PackedDomainSet.of(emptySet()))}
 @Test fun reportsBundledStorage(){val base=HostsParser.parse(java.io.File("src/main/assets/hosts").readText());val maximum=MaximalRules.parse(java.io.File("src/main/assets/hagezi-ultimate.txt").readText());val more=OisdRules.parse(java.io.File("src/main/assets/oisd-big.txt").readText());val names=MaximalRules.effective(base,maximum,true,more);val p=PackedDomainSet.of(names);assertEquals(names,p);println("PACKED domains=${p.size} payload_bytes=${p.storageBytes}")}
}
