package de.adshield.vpn

import android.app.PendingIntent
import android.os.Build
import kotlinx.coroutines.*
import android.content.Intent
import android.net.VpnService
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import de.adshield.MainActivity

class AdShieldTileService : TileService() {
    private val scope=CoroutineScope(SupervisorJob()+Dispatchers.Main.immediate)
    private var listening:Job?=null
    override fun onStopListening(){listening?.cancel();listening=null;super.onStopListening()}
    override fun onDestroy(){scope.cancel();super.onDestroy()}
    override fun onStartListening() {
        super.onStartListening()
        syncTile()
        listening?.cancel()
        listening=scope.launch { DnsVpnService.state.collect { syncTile() } }
    }

    // Intent overload is required below API 34; the newer overload is runtime guarded.
    @android.annotation.SuppressLint("StartActivityAndCollapseDeprecated")
    override fun onClick() {
        super.onClick()
        val current = DnsVpnService.state.value.stage
        if (current in setOf(Stage.ACTIVE, Stage.STARTING)) {
            startForegroundService(Intent(this, DnsVpnService::class.java).setAction(DnsVpnService.STOP))
        } else {
            if (VpnService.prepare(this) == null) {
                startForegroundService(Intent(this, DnsVpnService::class.java).setAction(DnsVpnService.START))
            } else {
                val intent = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                if (Build.VERSION.SDK_INT >= 34) {
                    startActivityAndCollapse(PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
                } else {
                    @Suppress("DEPRECATION")
                    startActivityAndCollapse(intent)
                }
            }
        }
        syncTile()
    }

    private fun syncTile() {
        val tile = qsTile ?: return
        val current = DnsVpnService.state.value.stage
        tile.state = when (current) {
            Stage.ACTIVE, Stage.STARTING -> Tile.STATE_ACTIVE
            else -> Tile.STATE_INACTIVE
        }
        tile.label = "AdShield"
        tile.subtitle = when (current) {
            Stage.ACTIVE -> "Aktiv"
            Stage.STARTING -> "Startet …"
            Stage.PAUSED -> "Pausiert"
            else -> "Aus"
        }
        tile.updateTile()
    }
}
