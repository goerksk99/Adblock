package de.adshield.core

/** Immutable Set API; only iteration materializes strings. Keys must be normalized ASCII. */
class PackedDomainSet private constructor(private val bytes:ByteArray,private val offsets:IntArray):AbstractSet<String>() {
    override val size:Int get()=offsets.size-1
    val storageBytes:Long get()=bytes.size.toLong()+offsets.size*4L
    override fun contains(element:String):Boolean {
        var low=0;var high=size-1
        while(low<=high){
            val mid=(low+high).ushr(1);val start=offsets[mid];val length=offsets[mid+1]-start
            var cmp=0;var i=0
            while(i<minOf(length,element.length)){
                cmp=(bytes[start+i].toInt() and 255)-element[i].code
                if(cmp!=0)break
                i++
            }
            if(cmp==0)cmp=length-element.length
            if(cmp==0)return true
            if(cmp<0)low=mid+1 else high=mid-1
        }
        return false
    }
    override fun iterator():Iterator<String> = object:Iterator<String>{
        private var index=0
        override fun hasNext()=index<size
        override fun next():String {
            if(!hasNext())throw NoSuchElementException()
            val at=index++;return String(bytes,offsets[at],offsets[at+1]-offsets[at],Charsets.US_ASCII)
        }
    }
    companion object {
        fun of(domains:Set<String>):PackedDomainSet {
            if(domains is PackedDomainSet)return domains
            val sorted=domains.sorted();val total=sorted.sumOf{it.length.toLong()}
            require(total<=Int.MAX_VALUE)
            val bytes=ByteArray(total.toInt());val offsets=IntArray(sorted.size+1);var at=0
            sorted.forEachIndexed { index,name ->
                require(name.all{it.code in 1..127})
                offsets[index]=at
                for(c in name)bytes[at++]=c.code.toByte()
            }
            offsets[sorted.size]=at
            return PackedDomainSet(bytes,offsets)
        }
    }
}
