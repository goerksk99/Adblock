package de.adshield.core

data class DnsLogEntry(
    val id: Long,
    val timestampMillis: Long,
    val domain: String,
    val qType: String,
    val outcome: Outcome
)

/** Strictly in-memory ring buffer (max 150 entries) for live troubleshooting and 1-tap rules. Never persisted to disk. */
class DnsLogBuffer(private val capacity: Int = 150) {
    private val lock = Any()
    init { require(capacity > 0) }
    private var nextId = 1L
    private val entries = ArrayDeque<DnsLogEntry>(capacity)
    @Volatile var enabled: Boolean = true

    val snapshot = kotlinx.coroutines.flow.MutableStateFlow<List<DnsLogEntry>>(emptyList())

    fun record(domain: String, qType: Int, outcome: Outcome) {
        if (!enabled) return
        val normalized = runCatching { Domains.normalize(domain) }.getOrNull() ?: return
        if (normalized.isEmpty()) return
        val typeName = org.xbill.DNS.Type.string(qType)
        synchronized(lock) {
            val item = DnsLogEntry(nextId++, System.currentTimeMillis(), normalized, typeName, outcome)
            entries.addFirst(item)
            while (entries.size > capacity) {
                entries.removeLast()
            }
            snapshot.value = entries.toList()
        }
    }

    fun clear() {
        synchronized(lock) { entries.clear(); snapshot.value = emptyList() }
    }
}
