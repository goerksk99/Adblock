package de.adshield.data

import android.content.Context
import android.util.AtomicFile
import de.adshield.core.HostsParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

const val FILTER_URL="https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts"
data class FilterInfo(val count:Int=0,val updated:Long=0,val digest:String="",val bundled:Boolean=true,val updating:Boolean=false)
class FilterRepository(private val context:Context,private val store:AppStore,private val http:OkHttpClient=OkHttpClient.Builder().connectTimeout(10,TimeUnit.SECONDS).readTimeout(20,TimeUnit.SECONDS).callTimeout(45,TimeUnit.SECONDS).build(),private val bundledText:()->String={context.assets.open("hosts").bufferedReader().use{it.readText()}}) {
    private val file=AtomicFile(File(context.filesDir,"hosts.current"))
    private val lock=Mutex()
    val info=MutableStateFlow(FilterInfo())
    val domains=MutableStateFlow<Set<String>>(emptySet())
    suspend fun load()=withContext(Dispatchers.IO) {
        val bundled=bundledText()
        val text=runCatching{file.openRead().bufferedReader().use{it.readText()}}.getOrNull()
        val parsed=text?.let{runCatching{HostsParser.parse(it)}.getOrNull()}
        publish(if(parsed!=null)text else bundled,parsed?:HostsParser.parse(bundled),parsed==null)
    }
    private fun publish(text:String,parsed:Set<String>,bundled:Boolean) {
        domains.value=parsed
        info.value=FilterInfo(parsed.size,if(bundled)0 else file.baseFile.lastModified(),MessageDigest.getInstance("SHA-256").digest(text.toByteArray()).joinToString(""){"%02x".format(it)},bundled)
    }
    suspend fun update():Boolean=lock.withLock {withContext(Dispatchers.IO) {
        info.value=info.value.copy(updating=true)
        try {
            val text=http.newCall(Request.Builder().url(FILTER_URL).build()).execute().use { response ->
                check(response.isSuccessful){"HTTP ${response.code}"}
                val body=checkNotNull(response.body)
                check(body.contentLength()<=HostsParser.MAX_BYTES){"Download ist zu groß"}
                val source=body.source();val buffer=okio.Buffer();var total=0L
                while(true){val read=source.read(buffer,8192);if(read<0)break;total+=read;check(total<=HostsParser.MAX_BYTES){"Download ist zu groß"}}
                buffer.readUtf8()
            }
            val parsed=HostsParser.parse(text)
            check(parsed.size>=domains.value.size/2){"Ungewöhnlich kleiner Filter; bisherige Liste bleibt erhalten"}
            val stream=file.startWrite()
            try {stream.write(text.toByteArray(Charsets.UTF_8));file.finishWrite(stream)}catch(e:Exception){file.failWrite(stream);throw e}
            publish(text,parsed,false);store.updateError("");true
        }catch(e:Exception){store.updateError("Filterupdate fehlgeschlagen: ${e.message?:"Netzwerkfehler"}. Bisherige Liste bleibt aktiv.");false}
        finally{info.value=info.value.copy(updating=false)}
    }}
}
