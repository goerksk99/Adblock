# AdShield

Private native Android-App zur lokalen DNS-Filterung, deutsch, ohne Konto, Werbung, Telemetrie, Root oder eigene Server. **Version 0.1.0 ist eine Entwicklungsversion**; siehe [Testbericht](TESTING.md) und [technische Grenzen](LIMITATIONS.md). Eine gebaute APK ist noch kein Nachweis, dass der vollständige VPN-Betrieb auf einem Galaxy S25 funktioniert.

Enthalten: echter DNS-only-VPN-Dienst mit IPv4/IPv6 und UDP/TCP, Quad9 DNS-over-HTTPS, gebündelte StevenBlack-Standardliste, validierte atomare Updates, globale Domainregeln, sichtbare App-Ausnahmen, lokale Tagesstatistiken, Hell-/Dunkelmodus, WorkManager und Always-on-Hilfe. Keine Behauptung zuverlässiger YouTube-/Instagram-/TikTok-Werbeblockierung oder vollständiger Pop-up-Verhinderung.

## APK installieren

Nach einem erfolgreichen Build liegt die signierte Debug-APK unter:

`app/build/outputs/apk/debug/app-debug.apk`

Eine bequem benannte Kopie wird für diese Sitzung unter `dist/AdShield-debug.apk` bereitgestellt, sofern im Testbericht als gebaut ausgewiesen.

1. APK auf dein Galaxy S25 übertragen und in „Eigene Dateien“ öffnen.
2. Falls Samsung nachfragt, das Installieren unbekannter Apps für genau diese Datei-App erlauben. Nur eine APK installieren, deren Herkunft du kennst. Keine globalen Schutzfunktionen pauschal deaktivieren. Samsung Auto Blocker oder Geräteverwaltung können Sideloading verhindern; eine vorhandene Einschränkung muss bewusst in den Geräteeinstellungen geprüft werden.
3. AdShield öffnen, „Aktivieren“ antippen und die Erklärung lesen. Androids VPN-Freigabe bestätigen. Die Benachrichtigungsfreigabe ist für die sichtbare Statusanzeige sinnvoll.
4. Eine normale Webseite öffnen und danach Statistiken ansehen. Bei Problemen ausschalten; eine passende Domain oder App gegebenenfalls als Ausnahme testen.
5. Erst nach bestandenem Funktionstest in „Einstellungen → Android-VPN-Einstellungen öffnen“ bei AdShield „Durchgehend aktives VPN“ aktivieren, wenn gewünscht. **„Verbindungen ohne VPN blockieren“ ausgeschaltet lassen.**
6. Auf Samsung bei Bedarf AdShield zu den Apps hinzufügen, die nie im Standby sind. Die genauen One-UI-Menüs können je nach Version abweichen.

Zum Deinstallieren zuerst Always-on ausschalten und dann die App normal entfernen. Dadurch werden auch lokale Regeln und Statistiken gelöscht. Für Updates derselben Installation muss dieselbe Signatur verwendet werden. Debug-Schlüssel sind Entwicklungsschlüssel; ein auf einer anderen Maschine gebautes APK kann die vorhandene App wegen einer anderen Signatur nicht ersetzen.

## Lokal bauen

Voraussetzungen: Android Studio mit SDK API 37.0 und Build Tools 37.0.0, JDK 21. Mindestgerät Android 10/API 29. Android-Studio-Projekt direkt aus diesem Verzeichnis öffnen. Keine lokalen SDK-Pfade oder Schlüssel sind eingecheckt. `ANDROID_HOME` setzen oder in einer **nicht eingecheckten** `local.properties` die SDK-Position konfigurieren. SDK-Lizenzbedingungen regulär über Android Studio/SDK Manager prüfen und akzeptieren.

```sh
./gradlew :app:testDebugUnitTest :app:assembleDebug :app:lintDebug
./gradlew :app:connectedDebugAndroidTest  # nur mit verbundenem kompatiblem Testgerät
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

Die Versionen stehen in `build.gradle.kts`, `app/build.gradle.kts` und `gradle/wrapper/gradle-wrapper.properties`. Der Gradle Wrapper ist enthalten und überprüft seinen Download per SHA-256. Für Windows ist `gradlew.bat` enthalten.

In dieser Cloud-Umgebung aktiviert der Helfer die vorhandenen Werkzeuge, den geerbten Proxy und den System-CA-Speicher, ohne Zertifikatsprüfungen abzuschalten:

```sh
python3 tools/cloud-gradle.py :app:testDebugUnitTest :app:assembleDebug :app:lintDebug
```

Das Hilfsskript enthält nur die lokalen Cloud-Werkzeugpfade, nicht die plattformunabhängige Projektkonfiguration. Netzwerk- und JDK-Einstellungen können über vorhandene Umgebungsvariablen überschrieben werden. Es führt keine Veröffentlichung durch.

## Release richtig signieren

Android Studio → Build → Generate Signed App Bundle / APK → APK. Einen eigenen Schlüssel erzeugen und außerhalb des Repositorys verschlüsselt und sicher sichern. Für App-Updates brauchst du denselben Schlüssel; nach Verlust lässt sich eine privat installierte App nicht unter Erhalt ihrer Daten aktualisieren.

Die Standard-Release-Variante enthält absichtlich keine eingebauten Signaturdaten. Alternativ:

```sh
./gradlew :app:assembleRelease
# Danach Android SDK zipalign und apksigner mit deinem extern verwahrten Keystore verwenden.
# apksigner fragt das Passwort interaktiv ab; nicht in Skripte oder Befehlsargumente schreiben.
zipalign -P 16 -f 4 app/build/outputs/apk/release/app-release-unsigned.apk AdShield-aligned.apk
apksigner sign --ks /sicherer/pfad/adshield-release.jks --out AdShield-release.apk AdShield-aligned.apk
apksigner verify --verbose AdShield-release.apk
```

Es wurde keine private Release-Signatur erzeugt. Keine Keystores oder Zugangsdaten einchecken.

## Weitere Dokumentation

* [Architektur und offizielle Recherchequellen](ARCHITECTURE.md)
* [Tests, Ergebnisse und Galaxy-S25-Checkliste](TESTING.md)
* [Grenzen und offene Validierung](LIMITATIONS.md)
* [Erklärung für Anfänger](LEARNING.md)
* [Filterquellen und Drittanbieter-Lizenzen](docs/THIRD_PARTY_NOTICES.md)

Unser eigener Quellcode steht unter MIT, siehe LICENSE. Die gebündelte Filterdatei enthält unabhängige Quellen mit unterschiedlichen Bedingungen, darunter nichtkommerzielle und Share-Alike-Lizenzen. Diese Bedingungen bleiben bestehen; die Gesamtdatei ist nicht pauschal MIT-lizenziert. Nutzung ist hier ausdrücklich privat, keine Play-Store-Veröffentlichung. Die Listen sind unverändert gebündelt; Normalisierung und Deduplizierung erfolgen nur zur Laufzeit.
