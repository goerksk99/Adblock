# AdShield

Private native Android-App zur lokalen DNS-Filterung, deutsch, ohne Konto, Werbung, Telemetrie, Root oder eigene Server. **Version 0.1.5 ist eine Entwicklungsversion**; siehe [Testbericht](TESTING.md) und [technische Grenzen](LIMITATIONS.md). Eine gebaute APK ist noch kein Nachweis, dass der vollständige VPN-Betrieb auf einem Galaxy S25 funktioniert.

Enthalten: echter DNS-only-VPN-Dienst mit IPv4/IPv6 und UDP/TCP, Quad9 DNS-over-HTTPS, StevenBlack-Standardliste plus HaGeZi Ultimate im voreingestellten Maximalmodus, validierte atomare Updates, globale Domainregeln, sichtbare App-Ausnahmen, lokale Tagesstatistiken, Hell-/Dunkelmodus, WorkManager und Always-on-Hilfe. Keine Behauptung zuverlässiger YouTube-/Instagram-/TikTok-Werbeblockierung oder vollständiger Pop-up-Verhinderung.

## APK installieren

Nach einem erfolgreichen Build liegt die signierte Debug-APK unter:

`app/build/outputs/apk/debug/app-debug.apk`

Eine bequem benannte Kopie wird für diese Sitzung unter `dist/AdShield-debug.apk` bereitgestellt, sofern im Testbericht als gebaut ausgewiesen.

1. APK auf dein Galaxy S25 übertragen und in „Eigene Dateien“ öffnen.
2. Falls Samsung nachfragt, das Installieren unbekannter Apps für genau diese Datei-App erlauben. Nur eine APK installieren, deren Herkunft du kennst. Keine globalen Schutzfunktionen pauschal deaktivieren. Samsung Auto Blocker oder Geräteverwaltung können Sideloading verhindern; eine vorhandene Einschränkung muss bewusst in den Geräteeinstellungen geprüft werden.
3. AdShield öffnen, „Aktivieren“ antippen und die Erklärung lesen. Androids VPN-Freigabe bestätigen. Die Benachrichtigungsfreigabe ist für die sichtbare Statusanzeige sinnvoll.
4. Eine normale Webseite öffnen und danach Statistiken ansehen. Bei Problemen ausschalten; eine passende Domain oder App gegebenenfalls als Ausnahme testen.
5. Erst nach bestandenem Funktionstest in „Einstellungen → Android-VPN-Einstellungen öffnen“ bei AdShield „Durchgehend aktives VPN“ aktivieren, wenn gewünscht. **„Verbindungen ohne VPN blockieren“ ausgeschaltet lassen.**
6. Auf Samsung bei Bedarf AdShield zu den Apps hinzufügen, die nie im Standby sind. Die genauen One-UI-Menüs können je nach Version abweichen.

Zum Deinstallieren zuerst Always-on ausschalten und dann die App normal entfernen. Dadurch werden auch lokale Regeln und Statistiken gelöscht. Für Updates derselben Installation muss dieselbe Signatur verwendet werden. Debug-Schlüssel sind Entwicklungsschlüssel; ein auf einer anderen Maschine gebautes APK kann die vorhandene App wegen einer anderen Signatur nicht ersetzen.

## Lokal bauen

Voraussetzungen: Android Studio mit SDK API 37.0 und Build Tools 37.0.0, JDK 21. Mindestgerät Android 10/API 29. Android-Studio-Projekt direkt aus diesem Verzeichnis öffnen. Keine lokalen SDK-Pfade oder Schlüssel sind eingecheckt. `ANDROID_HOME` setzen oder in einer **nicht eingecheckten** `local.properties` die SDK-Position konfigurieren. SDK-Lizenzbedingungen regulär über Android Studio/SDK Manager prüfen und akzeptieren.

```sh
./gradlew :app:testDebugUnitTest :app:assembleDebug :app:lintDebug
./gradlew :app:connectedDebugAndroidTest  # nur mit verbundenem kompatiblem Testgerät
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

Die Versionen stehen in `build.gradle.kts`, `app/build.gradle.kts` und `gradle/wrapper/gradle-wrapper.properties`. Der Gradle Wrapper ist enthalten und überprüft seinen Download per SHA-256. Für Windows ist `gradlew.bat` enthalten.

In dieser Cloud-Umgebung aktiviert der Helfer die vorhandenen Werkzeuge, den geerbten Proxy und den System-CA-Speicher, ohne Zertifikatsprüfungen abzuschalten:

```sh
python3 tools/cloud-gradle.py :app:testDebugUnitTest :app:assembleDebug :app:lintDebug
```

Das Hilfsskript enthält nur die lokalen Cloud-Werkzeugpfade, nicht die plattformunabhängige Projektkonfiguration. Netzwerk- und JDK-Einstellungen können über vorhandene Umgebungsvariablen überschrieben werden. Es führt keine Veröffentlichung durch.

## Release richtig signieren

Android Studio → Build → Generate Signed App Bundle / APK → APK. Einen eigenen Schlüssel erzeugen und außerhalb des Repositorys verschlüsselt und sicher sichern. Für App-Updates brauchst du denselben Schlüssel; nach Verlust lässt sich eine privat installierte App nicht unter Erhalt ihrer Daten aktualisieren.

Die Standard-Release-Variante enthält absichtlich keine eingebauten Signaturdaten. Alternativ:

```sh
./gradlew :app:assembleRelease
# Danach Android SDK zipalign und apksigner mit deinem extern verwahrten Keystore verwenden.
# apksigner fragt das Passwort interaktiv ab; nicht in Skripte oder Befehlsargumente schreiben.
zipalign -P 16 -f 4 app/build/outputs/apk/release/app-release-unsigned.apk AdShield-aligned.apk
apksigner sign --ks /sicherer/pfad/adshield-release.jks --out AdShield-release.apk AdShield-aligned.apk
apksigner verify --verbose AdShield-release.apk
```

Es wurde keine private Release-Signatur erzeugt. Keine Keystores oder Zugangsdaten einchecken.

## Weitere Dokumentation

* [Architektur und offizielle Recherchequellen](ARCHITECTURE.md)
* [Tests, Ergebnisse und Galaxy-S25-Checkliste](TESTING.md)
* [Grenzen und offene Validierung](LIMITATIONS.md)
* [Erklärung für Anfänger](LEARNING.md)
* [Filterquellen und Drittanbieter-Lizenzen](docs/THIRD_PARTY_NOTICES.md)

Unser eigener Quellcode steht unter MIT, siehe LICENSE. Die gebündelte Filterdatei enthält unabhängige Quellen mit unterschiedlichen Bedingungen, darunter nichtkommerzielle und Share-Alike-Lizenzen. Diese Bedingungen bleiben bestehen; die Gesamtdatei ist nicht pauschal MIT-lizenziert. Nutzung ist hier ausdrücklich privat, keine Play-Store-Veröffentlichung. Die Listen sind unverändert gebündelt; Normalisierung und Deduplizierung erfolgen nur zur Laufzeit.


## iOS-Portierung

Unter [ios/README.md](ios/README.md) liegt die separate iPhone-/iPad-Entwicklungsfassung mit SwiftUI und DNS-Packet-Tunnel. Der Swift-Kern ist mit 11 Tests geprüft. Ein vollständiger Xcode-Build, Apple-Signierung und echte iPhone-Tests stehen aus; es gibt noch keine installierbare IPA. Android und dessen APK bleiben davon unabhängig.


## Maximaler Schutz ab 0.1.2

Unter Einstellungen ist „Maximaler Schutz“ voreingeschaltet. Er kombiniert 78.215 StevenBlack-Domains, 272.267 HaGeZi-Ultimate-Domains (Stand 14.11.2026) und 43 gezielte Regeln aus den gemeldeten Testfällen. Nach Zusammenführung bleiben **326.947 eindeutige Regeln**; Elternregeln erfassen zusätzlich Subdomains. Alle 43 lesbaren Screenshot-Domains sind im Maximalmodus abgedeckt.

Das ist bewusst aggressiv: Trackingabhängige Funktionen, Fehlerberichte, Anmeldungen oder Anbieter-Dashboards können eingeschränkt werden. Erlaubte Domains haben Vorrang. Bei Problemen eine passende Domain erlauben, die betroffene App ausschließen oder den Maximalmodus ausschalten. Der Standardmodus verwendet wieder nur StevenBlack und eigene Regeln. Eine geänderte Domainregel greift auch bei bereits gefülltem internem DNS-Cache; Browser und Android können jedoch eigene Caches besitzen.

Beide Listen werden beim Update vollständig geprüft, dann in einer gemeinsamen AtomicFile gespeichert. Fehler in einer der Listen behalten den vorherigen Stand beider Listen bei. Ältere StevenBlack-Caches und Einstellungen werden beim Upgrade übernommen. HaGeZi-Daten stehen unter GPL-3.0; vollständige Lizenz in `app/src/main/assets/HAGEZI-LICENSE.txt` und in der App unter Lizenzen. Der iOS-Port wurde nicht geändert.

DNS kann keine einzelnen Werbeelemente oder URLs innerhalb einer Domain unterscheiden. Eigene DoH-Resolver, feste IP-Adressen und Werbung aus der Inhaltsdomain bleiben Grenzen. Der Cloud-Browser-Test bei Turtlecute ist weiterhin durch die Netzwerkregeln blockiert; lokale Regressionstests werden nicht als Live-Webseitentest ausgegeben.


## DNS-Umgehungsschutz ab 0.1.3

Der voreingeschaltete Schalter „Bekannte DNS-Umgehungen einschränken“ wirkt nur zusammen mit dem Maximalmodus. Er ergänzt 20 exakte Resolver-Routen (10 IPv4, 10 IPv6) zu ausgewählten Standard-Endpunkten von Cloudflare, Google, Quad9, AdGuard und OpenDNS. UDP-/TCP-DNS auf Port 53 wird vom lokalen Filter beantwortet und bei erlaubten Domains verschlüsselt an Quad9 weitergeleitet. Antworten behalten die adressierte Resolver-IP als Absender. Andere Verbindungen zu diesen dedizierten Resolver-IPs, insbesondere DoH/DoT/QUIC, werden verworfen, nicht entschlüsselt. Übriger Internetverkehr erhält weiterhin keine Standardroute durch den Tunnel.

Zusätzlich werden ausgewählte bekannte verschlüsselte Resolver-Domains lokal blockiert. AdShields eigene Quad9-Verbindung verwendet feste Bootstrap-Adressen und geschützte Sockets und bleibt davon ausgenommen. Die Liste ist statisch und nicht vollständig; andere, eigene, unbekannte oder zwischengespeicherte Resolver-Ziele können weiterhin umgehen. Keine Garantie gegen jedes DoH.

Ein Browser oder Android mit streng festgelegtem verschlüsseltem DNS kann durch diesen Schutz die Auflösung verlieren. Dann den Umgehungsschutz ausschalten oder den Browser wieder das System-DNS verwenden lassen. Eine Domain-Erlaubnis allein öffnet keinen HTTPS-/DoT-Zugriff auf eine erfasste Resolver-IP; dafür den Schalter ausschalten oder die gesamte App als Ausnahme wählen. Beim Wechsel werden aktive Tunnel neu aufgebaut. Der Standardmodus und eine Always-on-Filterpause verwenden keine zusätzlichen Resolver-Routen.

Der Modus ergänzt den Domainfilter, macht aus der App aber keinen Inhaltsblocker. Gegen Werbung innerhalb derselben Domain, Seitenelemente und Skripte hilft zusätzlich ein Browser mit Inhaltsblocker, etwa Firefox mit uBlock Origin. Dies kann eine DNS-App nicht gleichwertig ersetzen.


## Stabilität und Schutztest ab 0.1.4

- Unter Einstellungen → „Schutz jetzt prüfen“ wird über den realen AdShield-DNS-Pfad eine lokale Sperre samt interner Sperrkennzeichnung und normale DNS-Auflösung geprüft. Fehlende Sperre, Auflösungsfehler, ungültige Antworten und Zeitüberschreitung werden unterschieden. Striktes Android Private DNS wird als möglicher Konflikt angezeigt. Der Test garantiert keine Werbefreiheit und prüft nicht das eigene DoH-Verhalten anderer Browser.
- Statistikereignisse werden pro Tag zusammengezählt und in kurzen Batches gespeichert. Langsames SQLite blockiert keine DNS-Arbeitsthreads mehr. Es werden weiterhin keine Domainhistorien gespeichert. Der Puffer umfasst höchstens acht Tagesgruppen; bei außergewöhnlichen Tageswechseln wird ein unvollständiger Zähler ausdrücklich angezeigt. Löschen verwirft auch wartende alte Zählergenerationen.
- Eine nach dem Cache-Leeren eintreffende alte DNS-Antwort darf den Cache nicht neu befüllen. Verspätete Fehler alter Tunnel dürfen eine neue Verbindung nicht beenden.
- Netzwechselmeldungen werden kurz gebündelt; bei Transportfehlern gibt es eine begrenzte erneute DNS-Prüfung. Während dieser Prüfung entscheidet der Verbindungstest über das Beenden, statt paralleler Fehlermeldungen einzelner Pakete.
- App-Liste und Icons werden erst beim Öffnen des Apps-Tabs geladen. Beim Start wird statt einer irreführenden Nullzahl angezeigt, dass Filter geladen werden.

Die Regeln und Grenzen aus 0.1.3 bleiben unverändert. Akkuverbrauch und langfristige Stabilität auf einem Galaxy S25 sind weiterhin auf dem echten Gerät zu messen. Verbesserte Abläufe und bestandene Tests sind keine 10/10-Zertifizierung.


## Zusätzliche Abdeckung ab 0.1.5

Der Maximalmodus ergänzt OISD Big (228.023 Domain-Wildcardregeln, Stand 14.11.2026) zu StevenBlack, HaGeZi Ultimate und den gezielten Ergänzungen. Zusammen entstehen **455.868 eindeutige Listenregeln**. Gemessen gegen die bisherigen Regeln einschließlich Eltern-Domains sind **121.559 OISD-Domains erstmals erfasst**. Das ist zusätzliche Domain-Abdeckung, kein Prozentsatz entfernter sichtbarer Werbung; OISD enthält auch Tracking- und schädliche Domains.

Alle drei Quellen werden auf Größe, Format, gültige Domainnamen, deklarierte Anzahl und Duplikate geprüft und gemeinsam atomar gespeichert. Ein ungültiger OISD-Download behält alle bisherigen Listen bei. Ältere Zwei-Listen-Snapshots können mit der mitgelieferten OISD-Liste ergänzt werden. OISD bleibt als unveränderte Quelldatei mit Herkunfts- und GPL-3.0-Hinweisen enthalten; vollständige Lizenz unter `OISD-LICENSE.txt` und in der App.

Standardmodus, eigene Erlaubnisse und App-Ausnahmen bleiben unverändert. Die zusätzliche Quelle wird nur im Maximalmodus angewendet. Weiterhin keine Zusage für Inhaltsdomain-Werbung oder unbekannte DNS-Umgehungen; für Seitenelemente ist zusätzlich ein Browser-Inhaltsblocker sinnvoll. Der Statistik-Prozentsatz ist kein Qualitätswert: gewünschte DNS-Anfragen müssen weiter erlaubt bleiben.
