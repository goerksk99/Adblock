# Änderungen

## 0.1.1

- Startfehler behoben: Den nativen TCP-Socket durch Bindung anlegen, bevor Android ihn vom VPN ausnimmt; erst danach verbinden.
- Alle SocketFactory-Überladungen binden und schützen in der richtigen Reihenfolge und schließen fehlgeschlagene Sockets.
- Fehlerursachen für den DNS-Start bleiben erhalten und werden verständlich und ohne Domainhistorie angezeigt.
- 58 Unit-Tests und 9 Android-Integrationstests bestanden, darunter echte native Socket-Protection- und IPv4-/IPv6-Übertragungstests.
- Dieselbe APK-Signatur und höherer Versionscode für ein Update ohne Datenverlust.

## 0.1.0

Erste native Entwicklungsfassung. Die damaligen VPN-Tests mit Testresolver deckten den jetzt korrigierten realen Socket-Aufbau zum Upstream nicht ab.
